//INICIAR CONEXIÓN A LA BD DE SQL SERVER Y ALMACENAR LOS DATOS INGRESADOS EN EL REGISTRO.HTML
const express = require('express');
const sql = require('mssql');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// Configuración de conexión a SQL Server
const config = {
    user: 'SserverUser',
    password: 'user123',
    server: 'localhost',
    database: 'RegistrarUsuarios',
    options: {
        encrypt: false,
        trustServerCertificate: true
    }
};

// Probar conexión al iniciar
let pool;
sql.connect(config).then((p) => {
  pool = p;
  console.log("Conexión a SQL Server exitosa");
}).catch(err => {
  console.error("Error al conectar a SQL Server:", err);
});


app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public')); 

// REGISTRO
app.post('/registrar', async (req, res) => {
    const { nombre, contraseña, correo } = req.body;

    try {
        const result = await pool.request()
            .input('nombre', sql.VarChar, nombre)
            .input('contraseña', sql.VarChar, contraseña)
            .input('correo', sql.VarChar, correo)
            .query('INSERT INTO Usuarios (nombre, contraseña, correo) VALUES (@nombre, @contraseña, @correo)');

        res.send('Usuario registrado');
    } catch (err) {
        console.error('Error al registrar:', err);
        res.status(500).send('Error al registrar usuario');
    }
});

//LOGIN
app.post('/login', async (req, res) => {
    const { correo, contraseña } = req.body;

    try {
        const result = await pool.request()
            .input('correo', sql.VarChar, correo)
            .input('contraseña', sql.VarChar, contraseña)
            .query('SELECT * FROM Usuarios WHERE correo = @correo AND contraseña = @contraseña');

        if (result.recordset.length > 0) {
            res.json({ success: true });
        } else {
            res.json({ success: false });
        }
    } catch (err) {
        console.error('Error al consultar la base de datos:', err);
        res.status(500).json({ success: false });
    }
});

app.listen(port, () => {
    console.log(`Servidor corriendo en http://localhost:${port}`);
});