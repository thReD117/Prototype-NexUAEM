//REDIRIGIR AL LOGIN.HTML DESPUÉS DE ALMACENAR LOS DATOS EN LA BD
document.getElementById('btnRegistrarse').addEventListener('click', async () => {
  // Obtiene valores del formulario
  const nombre = document.querySelector('input[placeholder="Nombre"]').value;
  const contraseña = document.querySelector('input[placeholder="Contraseña"]').value;
  const correo = document.querySelector('input[placeholder="Correo"]').value;

  // Envía datos al servidor
  const respuesta = await fetch('/registrar', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ nombre, contraseña, correo })
  });

  if (respuesta.ok) {
    // Redirige a Login.html después de registrarse
    window.location.href = 'Login.html';
  } else {
    alert('Error al registrarse');
  }
});


