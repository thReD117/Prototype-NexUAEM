const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { createClient } = require('@supabase/supabase-js');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Configuración de Supabase
const SUPABASE_URL = 'https://inwfvquxpwsbhcujxojz.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imlud2Z2cXV4cHdzYmhjdWp4b2p6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDczMjg4MTcsImV4cCI6MjA2MjkwNDgxN30.Vq8Y2vnt07QqROLiVNH-FYGZet5vOplfKMWRuxivYyE';

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// Ruta para iniciar sesión
app.post('/login', async (req, res) => {
    console.log('Cuerpo recibido:', req.body);
    const { email, password } = req.body;
    console.log('Email recibido:', email);
    console.log('Password recibido:', password);

    const { data, error } = await supabase
        .from('Users')
        .select('*')
        .eq('email', email) // ← corregido aquí
        .eq('password', password)
        .maybeSingle();

    console.log('Resultado de Supabase:', data);
    console.log('Error:', error);
    console.log('Email (verificado):', JSON.stringify(email));
    console.log('Password (verificado):', JSON.stringify(password));


    if (error || !data) {
        return res.status(401).json({ message: 'Correo o contraseña incorrectos' });
    
    }
    res.json({ message: `Inicio de sesión exitoso, bienvenido ${data.complete_Name}`, user: data });

});

// Iniciar el servidor
app.listen(3000, () => {
  console.log('Servidor corriendo en http://localhost:3000');
});
