document.querySelector('.btnIniciar').addEventListener('click', async (e) => {
    e.preventDefault();

    const email = document.getElementById('correo').value;
    const password = document.getElementById('clave').value;

    try {
        const response = await fetch('http://localhost:3000/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const result = await response.json();

        if (response.ok) {
            alert('Bienvenido, ' + result.user.name);
        } else {
            alert(result.message);
        }
    } catch (error) {
        alert('Error de conexión con el servidor');
        console.error(error);
    }
});
