// Server.js - CÓDIGO ACTUALIZADO

const express = require('express');
const sql = require('mssql');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// Configuración de conexión a SQL Server
const config = {
    user: 'SserverUser',
    password: 'user123',
    server: 'localhost',
    database: 'RegistrarUsuarios',
    options: {
        encrypt: false,
        trustServerCertificate: true
    }
};

// Probar conexión al iniciar
let pool;
sql.connect(config).then((p) => {
    pool = p;
    console.log("Conexión a SQL Server exitosa");
}).catch(err => {
    console.error("Error al conectar a SQL Server:", err);
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public'));

// REGISTRO
app.post('/registrar', async (req, res) => {
    const { nombre, contraseña, correo } = req.body;
    try {
        const result = await pool.request()
            .input('nombre', sql.VarChar, nombre)
            .input('contraseña', sql.VarChar, contraseña)
            .input('correo', sql.VarChar, correo)
            .query('INSERT INTO Usuarios (nombre, contraseña, correo) VALUES (@nombre, @contraseña, @correo)');
        res.status(201).json({ success: true, message: 'Usuario registrado correctamente' });
    } catch (err) {
        console.error('Error al registrar:', err);
        res.status(500).send('Error al registrar usuario');
    }
});

// LOGIN - Modificado para devolver más información del usuario
app.post('/login', async (req, res) => {
    const { correo, contraseña } = req.body;
    console.log('Datos recibidos en login:', correo, contraseña);
    try {
        const result = await pool.request()
            .input('correo', sql.VarChar, correo)
            .input('contraseña', sql.VarChar, contraseña)
            .query('SELECT ID, Nombre, Correo FROM Usuarios WHERE correo = @correo AND contraseña = @contraseña'); // Seleccionar más campos
        console.log('Resultado consulta login:', result.recordset);
        if (result.recordset.length > 0) {
            // Devuelve el ID, Nombre y Correo del usuario
            res.json({ success: true, user: result.recordset[0] });
        } else {
            res.json({ success: false });
        }

    } catch (err) {
        console.error('Error al consultar la base de datos:', err);
        res.status(500).json({ success: false });
    }
});

app.listen(port, () => {
    console.log(`Servidor corriendo en http://localhost:${port}`);
});

// Crear nuevo proyecto
app.post('/api/proyectos', async (req, res) => {
    const { ID, Nombre, Info, Fecha, Participantes } = req.body;
    try {
        await pool.request()
            .input('ID', sql.Int, ID)
            .input('Nombre', sql.VarChar, Nombre)
            .input('Info', sql.Text, Info)
            .input('Fecha', sql.Date, Fecha)
            .input('Participantes', sql.Int, Participantes)
            .query('INSERT INTO Proyectos (ID, Nombre, Info, Fecha, Participantes) VALUES (@ID, @Nombre, @Info, @Fecha, @Participantes)');
        res.status(201).send('Proyecto creado');
    } catch (err) {
        console.error('Error al crear proyecto: ', err);
        res.status(500).send('Error al crear proyecto');
    }
});

// Obtener proyectos del usuario autenticado
app.get('/api/proyectos/:ID', async (req, res) => {
    const ID = req.params.ID;
    try {
        const result = await pool.request()
            .input('ID', sql.Int, ID)
            .query('SELECT * FROM Proyectos WHERE ID = @ID');
        res.json(result.recordset);
    } catch (err) {
        console.error('Error al obtener proyectos:', err);
        res.status(500).send('Error al obtener proyectos');
    }
});

// Obtener todos los proyectos
app.get('/api/proyectos', async (req, res) => {
    try {
        const result = await pool.request()
            .query('SELECT * FROM Proyectos');
        res.json(result.recordset);
    } catch (err) {
        console.error('Error al obtener todos los proyectos:', err);
        res.status(500).send('Error al obtener proyectos');
    }
});

app.get('/api/proyecto/:proyectoId', async (req, res) => {
    const proyectoId = req.params.proyectoId;
    try {
        const result = await pool.request()
            .input('ID', sql.Int, proyectoId)
            .query('SELECT * FROM Proyectos WHERE ID = @ID');

        if (result.recordset.length === 0) {
            return res.status(404).send({ error: 'Proyecto no encontrado' });
        }

        res.json(result.recordset[0]);
    } catch (err) {
        console.error('Error al obtener proyecto:', err);
        res.status(500).send('Error al obtener proyecto');
    }
});

// --- NUEVO ENDPOINT: Obtener información de un usuario por su ID ---
app.get('/api/usuarios/:ID', async (req, res) => {
    const usuarioID = req.params.ID;
    try {
        const result = await pool.request()
            .input('usuarioID', sql.Int, usuarioID)
            .query('SELECT ID, Nombre, Correo FROM Usuarios WHERE ID = @usuarioID');

        if (result.recordset.length > 0) {
            res.json(result.recordset[0]);
        } else {
            res.status(404).json({ message: 'Usuario no encontrado' });
        }
    } catch (err) {
        console.error('Error al obtener información del usuario:', err);
        res.status(500).send('Error al obtener información del usuario');
    }
});

// --- NUEVO ENDPOINT: Obtener notificaciones para un usuario ---
// Para esto, necesitamos una tabla 'Notificaciones' o 'ActividadForo'
// que registre los cambios. Por simplicidad, aquí simularé algunas notificaciones
// basándome en los proyectos a los que el usuario "pertenece" (es el creador).
// En una implementación real, esto sería más complejo, rastreando comentarios, etc.
app.get('/api/notificaciones/:userID', async (req, res) => {
    const userID = req.params.userID;
    try {
        // En un escenario real, buscarías en una tabla de 'Notificaciones'
        // que esté vinculada a los usuarios.
        // Aquí, como ejemplo, vamos a buscar todos los proyectos creados por el usuario
        // y generar notificaciones simuladas para ellos.
        const userProjectsResult = await pool.request()
            .input('userID', sql.Int, userID)
            .query('SELECT ProyectoID, Nombre, Info, Fecha FROM Proyectos WHERE ID = @userID'); // Asumiendo que 'ID' en Proyectos es el ID del Creador

        const notifications = [];
        const currentDate = new Date();

        userProjectsResult.recordset.forEach(project => {
            // Simular notificaciones de actualización para los proyectos del usuario
            // Esto es solo un ejemplo. Necesitarías una lógica real de "actualización".
            // Podrías comparar 'Fecha' con la última vez que el usuario revisó las notificaciones.
            notifications.push({
                proyectoID: project.ProyectoID,
                nombreProyecto: project.Nombre,
                tipoNotificacion: "Actualización en tu Proyecto",
                mensaje: `Tu proyecto "${project.Nombre}" fue modificado o ha recibido actividad.`,
                fecha: new Date(currentDate.getTime() - Math.random() * 86400000).toISOString() // Fecha aleatoria en el último día
            });
        });

        // También, puedes añadir notificaciones genéricas o de colaboración
        // (esto requeriría otra tabla de 'Colaboraciones' o 'ParticipantesProyecto')
        const collaborativeProjectsResult = await pool.request()
            .input('userID', sql.Int, userID)
            .query(`
                SELECT P.ProyectoID, P.Nombre
                FROM Proyectos P
                JOIN Colaboraciones C ON P.ProyectoID = C.ProyectoID -- Suponiendo una tabla Colaboraciones
                WHERE C.UserID = @userID AND P.ID <> @userID -- Si el usuario no es el creador
            `);

        collaborativeProjectsResult.recordset.forEach(project => {
             notifications.push({
                proyectoID: project.ProyectoID,
                nombreProyecto: project.Nombre,
                tipoNotificacion: "Actividad en Proyecto Colaborativo",
                mensaje: `Se detectó actividad en el proyecto "${project.Nombre}" en el que colaboras.`,
                fecha: new Date(currentDate.getTime() - Math.random() * 86400000).toISOString()
            });
        });


        res.json(notifications);

    } catch (err) {
        console.error('Error al obtener notificaciones:', err);
        res.status(500).send('Error al obtener notificaciones');
    }
});