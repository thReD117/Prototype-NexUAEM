//INICIAR CONEXIÓN A LA BD DE SQL SERVER Y ALMACENAR LOS DATOS INGRESADOS EN EL REGISTRO.HTML
const express = require('express');
const sql = require('mssql');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// Configuración de conexión a SQL Server
const config = {
    user: 'SserverUser',
    password: 'user123',
    server: 'localhost',
    database: 'RegistrarUsuarios',
    options: {
        encrypt: false,
        trustServerCertificate: true
    }
};

// Probar conexión al iniciar
let pool;
sql.connect(config).then((p) => {
  pool = p;
  console.log("Conexión a SQL Server exitosa");
}).catch(err => {
  console.error("Error al conectar a SQL Server:", err);
});


app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public')); 

// REGISTRO
app.post('/registrar', async (req, res) => {
    const { nombre, contraseña, correo } = req.body;
    try {
        const result = await pool.request()
            .input('nombre', sql.VarChar, nombre)
            .input('contraseña', sql.VarChar, contraseña)
            .input('correo', sql.VarChar, correo)
            .query('INSERT INTO Usuarios (nombre, contraseña, correo) VALUES (@nombre, @contraseña, @correo)');
            res.status(201).json({ success: true, message: 'Usuario registrado correctamente' });
        } catch (err) {
        console.error('Error al registrar:', err);
        res.status(500).send('Error al registrar usuario');
    }
});

//LOGIN
app.post('/login', async (req, res) => {
    const { correo, contraseña } = req.body;
    console.log('Datos recibidos en login:', correo, contraseña);
    try {
        const result = await pool.request()
            .input('correo', sql.VarChar, correo)
            .input('contraseña', sql.VarChar, contraseña)
            .query('SELECT * FROM Usuarios WHERE correo = @correo AND contraseña = @contraseña');
            console.log('Resultado consulta login:', result.recordset);
        if (result.recordset.length > 0) {
            res.json({ success: true, id: result.recordset[0].id }); // <-- Devuelve el id
        } else {
            res.json({ success: false });
        }

    } catch (err) {
        console.error('Error al consultar la base de datos:', err);
        res.status(500).json({ success: false });
    }
});

app.listen(port, () => {
    console.log(`Servidor corriendo en http://localhost:${port}`);
});

//Crear nuevo proyecto
app.post('/api/proyectos', async (req, res) => {
    const {ID, Nombre, Info, Fecha, Participantes} = req.body;
    try{

            await pool.request()
            .input('ID', sql.Int, ID)
            .input('Nombre', sql.VarChar, Nombre)
            .input('Info', sql.Text, Info)
            .input('Fecha', sql.Date, Fecha)
            .input('Participantes', sql.Int, Participantes)
            .query('INSERT INTO Proyectos (ID, Nombre, Info, Fecha, Participantes) VALUES (@ID, @Nombre, @Info, @Fecha, @Participantes)');
            res.status(201).send('Proyecto creado');
        }catch(err){
            console.error('Error al crear proyecto: ', err);
            res.status(500).send('Error al crear proyecto');
        }

});

// Obtener proyectos del usuario autenticado
app.get('/api/proyectos/:ID', async (req, res) => {
    const ID = req.params.ID;
    try {
        const result = await pool.request()
            .input('ID', sql.Int, ID)
            .query('SELECT * FROM Proyectos WHERE ID = @ID');
        res.json(result.recordset);
    } catch (err) {
        console.error('Error al obtener proyectos:', err);
        res.status(500).send('Error al obtener proyectos');
    }
});

//Obtener todos los proyectos
app.get('/api/proyectos', async (req, res) => {
    try {
        const result = await pool.request()
            .query('SELECT * FROM Proyectos');
        res.json(result.recordset);
    } catch (err) {
        console.error('Error al obtener todos los proyectos:', err);
        res.status(500).send('Error al obtener proyectos');
    }
});

app.get('/api/proyecto/:proyectoId', async (req, res) => {
    const proyectoId = req.params.proyectoId;
    try {
        const result = await pool.request()
            .input('ID', sql.Int, proyectoId)
            .query('SELECT * FROM Proyectos WHERE ID = @ID');

        if (result.recordset.length === 0) {
            return res.status(404).send({ error: 'Proyecto no encontrado' });
        }

        res.json(result.recordset[0]);
    } catch (err) {
        console.error('Error al obtener proyecto:', err);
        res.status(500).send('Error al obtener proyecto');
    }
});